import json
import os
import time
import logging
import hashlib
from typing import List, Callable, Dict, Any
from tqdm import tqdm
import urllib3
from urllib3.util.retry import Retry
import ray

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

DEFAULT_API_KEY = ""
DEFAULT_NUM_WORKERS = 100

@ray.remote(num_cpus=1)
def custom_gpt_api(
    system_content: str,
    user_content: str,
    image_url: str | None = None,
    post_process: Callable = lambda x: x,
) -> Any:
    messages = [
        {'role': 'system', 'content': system_content},
        {
            'role': 'user',
            "content": [
                {"type": "text", "text": user_content},
            ],
        },
    ]

    openai_api = ''

    params_gpt = {
        'model': 'gpt-4o',
        'messages': messages,
        'temperature': 0.05,
    }
    url = openai_api + '/v1/chat/completions'

    headers = {
        'Content-Type': 'application/json',
        'Authorization': DEFAULT_API_KEY,
        'Connection':'close',
    }

    retry_strategy = Retry(
        total=5,
        backoff_factor=0.1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=['POST'],
        raise_on_redirect=False,
        raise_on_status=False,
    )
    http = urllib3.PoolManager(
        retries=retry_strategy,
    )
    encoded_data = json.dumps(params_gpt).encode('utf-8')
    max_try = 1000
    while max_try > 0:
        try:
            response = http.request('POST', url, body=encoded_data, headers=headers)
            if response.status == 200:
                response = json.loads(response.data.decode('utf-8'))['choices'][0]['message']['content']
                logging.info(response)
                break
            else:
                err_msg = f'Error accessing OpenAI API, status code: {response.status} response: {response.data.decode("utf-8")}'
                logging.error(err_msg)
                time.sleep(3)
                max_try -= 1
                continue
        except Exception as e:
            err_msg = f'Error accessing OpenAI API: {str(e)}'
            logging.error(err_msg)
            time.sleep(3)
            max_try -= 1
            continue
    else:
        print('custom proxy API call failed...')
        response = 'custom proxy API call failed...'

    return post_process(response)

def generate_hash_uid(to_hash: dict | tuple | list | str, model_name: str = None) -> str:
    json_string = json.dumps(to_hash, sort_keys=True)
    
    if model_name:
        json_string = f"{model_name}_{json_string}"

    hash_object = hashlib.sha256(json_string.encode())
    hash_uid = hash_object.hexdigest()

    return hash_uid

def api(
    system_contents: List[str],
    user_contents: List[str],
    image_urls: List[str] | None = None,
    num_workers: int = DEFAULT_NUM_WORKERS,
    post_process: Callable = lambda x: x,
    hash_checker: Callable = lambda x: True,
    cache_dir: str = './cache',
    model_name: str = None,
) -> List[Any]:
    if len(system_contents) != len(user_contents):
        raise ValueError('length of system_contents and user_contents must be the same')
    server = custom_gpt_api

    api_interaction_count = 0
    ray.init(ignore_reinit_error=True)

    contents = list(enumerate(zip(system_contents, user_contents)))
    bar = tqdm(total=len(system_contents))
    results = [None] * len(system_contents)
    
    uids = [generate_hash_uid(content, model_name) for content in contents]
    
    not_finished = []
    while True:

        if len(not_finished) == 0 and len(contents) == 0:
            break

        while len(not_finished) < num_workers and len(contents) > 0:
            index, content = contents.pop()
            uid = uids[index]
            cache_path = os.path.join(cache_dir, f'{uid}.json')
            if os.path.exists(cache_path):
                with open(cache_path, 'r', encoding='utf-8') as f:
                    try:
                        result = json.load(f)
                    except:
                        os.remove(cache_path)
                        continue
                results[index] = result
                bar.update(1)
                continue

            future = server.remote(content[0], content[1], post_process)
            not_finished.append([index, future])
            api_interaction_count += 1

        if len(not_finished) == 0:
            continue

        indices, futures = zip(*not_finished)

        finished, not_finished_futures = ray.wait(list(futures), timeout=1.0)

        finished_indices = [indices[futures.index(task)] for task in finished]

        for i, task in enumerate(finished):
            results[finished_indices[i]] = ray.get(task)
            uid = uids[finished_indices[i]]
            cache_path = os.path.join(cache_dir, f'{uid}.json')
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(results[finished_indices[i]], f, ensure_ascii=False, indent=4)

        not_finished = [(index, future) for index, future in not_finished if future not in finished]

        bar.update(len(finished))
    bar.close()

    assert all(result is not None for result in results)

    ray.shutdown()
    print(f'API call count: {api_interaction_count}')

    return results 