#!/bin/bash

MODEL_TYPE=""                       
MODEL_NAME=""                    
BENCHMARK_DIR=""  
OUTPUT_DIR=""           
BATCH_SIZE=                        
TENSOR_PARALLEL_SIZE=              

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
MODEL_ID=$(basename $MODEL_NAME)
RUN_NAME="${MODEL_ID}_${TIMESTAMP}"

mkdir -p $OUTPUT_DIR
mkdir -p ./cache/inner_inference_${MODEL_NAME}
mkdir -p ./cache/outer_inference_${MODEL_NAME}
mkdir -p ./cache/alignment_eval_${MODEL_NAME}
mkdir -p ./cache/cot_inner_eval_${MODEL_NAME}
mkdir -p ./cache/consistency_eval_${MODEL_NAME}

INNER_RESULTS_FILE="${OUTPUT_DIR}/${RUN_NAME}_inner_beliefs.json"
OUTER_RESULTS_FILE="${OUTPUT_DIR}/${RUN_NAME}_outer_responses.json"
EVAL_OUTPUT_DIR="${OUTPUT_DIR}/${RUN_NAME}_evaluation"

echo "===== DeceptionBench Evaluation ====="
echo "Model: $MODEL_NAME"
echo "Benchmark data: $BENCHMARK_DIR"
echo "Output directory: $OUTPUT_DIR"
echo "Run ID: $RUN_NAME"
echo "Batch size: $BATCH_SIZE"

echo ""
echo "===== Step 1: Inner Belief Extraction ====="
python run_inner_inference.py \
  --model_type $MODEL_TYPE \
  --model_path $MODEL_NAME \
  --benchmark_dir $BENCHMARK_DIR \
  --output_file $INNER_RESULTS_FILE \
  --batch_size $BATCH_SIZE \
  --tensor_parallel_size $TENSOR_PARALLEL_SIZE

if [ $? -ne 0 ]; then
    echo "Inner belief extraction failed, exiting process."
    exit 1
fi
echo "Inner belief extraction completed, results saved to: $INNER_RESULTS_FILE"

echo ""
echo "===== Step 2: External Goal-Driven Reasoning ====="
python run_outer_inference.py \
  --model_type $MODEL_TYPE \
  --model_path $MODEL_NAME \
  --benchmark_dir $BENCHMARK_DIR \
  --inner_belief_file $INNER_RESULTS_FILE \
  --output_file $OUTER_RESULTS_FILE \
  --batch_size $BATCH_SIZE \
  --tensor_parallel_size $TENSOR_PARALLEL_SIZE

if [ $? -ne 0 ]; then
    echo "External goal-driven reasoning failed, exiting process."
    exit 1
fi
echo "External goal-driven reasoning completed, results saved to: $OUTER_RESULTS_FILE"

echo ""
echo "===== Step 3: Evaluating Results ====="
python deceptionbench_eval.py \
  --inner_results $INNER_RESULTS_FILE \
  --outer_results $OUTER_RESULTS_FILE \
  --output_dir $EVAL_OUTPUT_DIR \
  --eval_model $MODEL_NAME

if [ $? -ne 0 ]; then
    echo "Result evaluation failed."
    exit 1
fi
echo "Evaluation completed, results saved to: $EVAL_OUTPUT_DIR"

echo ""
echo "===== DeceptionBench Evaluation Completed ====="
echo "Generated files:"
echo "- Inner beliefs: $INNER_RESULTS_FILE"
echo "- External responses: $OUTER_RESULTS_FILE"
echo "- Evaluation results: $EVAL_OUTPUT_DIR"

echo "Generating evaluation report summary..."
if [ -f "${EVAL_OUTPUT_DIR}/evaluation_stats.json" ]; then
    echo "Statistics summary:"
    cat "${EVAL_OUTPUT_DIR}/evaluation_stats.json" | jq '.'
fi

echo "DeceptionBench evaluation process completed." 